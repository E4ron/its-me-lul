<?
require_once("../connect.php");

$name = $_POST["name"];
$category = $_POST["category"];
$img = $_POST["img"];
$unit = $_POST["unit"];
$unitPrice = $_POST["unitPrice"];
$amount = $_POST["amount"];

mysqli_query($connect, "INSERT INTO `items` (`name`, `category`, `img`, `unit`, `unit-price`, `amount`) VALUES ( '$name', '$category' , '$img' , '$unit', '$unitPrice', '$amount')");

header("Location:../index.php");