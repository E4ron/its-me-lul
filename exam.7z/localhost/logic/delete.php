<?
require_once("../connect.php");

$id = $_POST["id"];

if(!empty($id)){
    $del = "DELETE FROM items WHERE id = '$id'";
}

if ($connect->query($del)) {
    header("Location:../index.php");
    }
    else {
        print_r("Error");
    }