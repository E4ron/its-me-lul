<?
require_once("../connect.php");

$id = $_POST["id"];
$amount = $_POST["amount"];

if(!empty($id)){
    $sql = "UPDATE items SET amount ='$amount' WHERE id ='$id'";
}
echo $id;
echo "111";

if ($connect->query($sql)) {
    header("Location:../index.php");
    }
    else {
        print_r("Error");
    }