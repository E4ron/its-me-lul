<?php 
    require_once("connect.php");
?>

<!doctype html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>doc</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
        <link href="css/style.css" rel="stylesheet">
    </head>
    <body>
        <h2>Форма закупки</h2>
		<div class="create">
    	    <form action="logic/add.php" method="POST">
    	        <input type="text" name="name" placeholder="name">
    	        <input type="text" name="category" placeholder="category">
    	        <input type="text" name="img" placeholder="n.jpg">
                <select name="unit">
					<option value="гр.">гр</option>
					<option value="мл.">мл</option>
					<option value="шт.">шт</option>
				</select>
                <input type="text" name="unitPrice" placeholder="Цена за единицу">
                <input type="text" name="amount" placeholder="Кол. на складе">
    	        <button type="submit">Добавить</button>
    	    </form>
    	</div>
        <h2>Форма списания/выдачи</h2>
        <div class="update">
    	    <form action="logic/update.php" method="POST">
                    <select name="id">
                        <?php if($result = mysqli_query($connect, "SELECT * FROM `items`")): foreach($result as $row):?>
				            <option value="<?= $row['id'] ?>"><?php echo $row["name"];?></option>
                        <?php endforeach;endif;?>
				    </select>
                
                <input type="text" name="amount" placeholder="Кол. на складе">
    	        <button type="submit">Изменить</button>
    	    </form>
    	</div>
        <h2>Ингредиенты</h2>
        <?php if($result = mysqli_query($connect, "SELECT * FROM `items`")): foreach($result as $row):?> 
			<div class="aaa">
                <div class="2">
					<img src="img/<?php echo $row["img"];?>">
				</div>
				<div class="aaa">
					<span class="4"><?php echo $row["category"];?> | <?php echo $row["name"];?></span>
				</div>
				<div class="aaa">
                    <span class="6">На складе: <?php echo $row["amount"]?> | 1<?php echo $row["unit"];?> - <?php echo $row["unit-price"];?>p</span>
				</div>
                <div class="aaa">
                    <form action="logic/delete.php" method="POST">
                        <input type="hidden" name="id" value="<?= $row['id'] ?>">
                        <button type="submit">Списать</button>
                    </form>
				</div>
			</div>
		<?php endforeach;endif;?>
    </body>
</html>