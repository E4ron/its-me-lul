<?php 
$connect = mysqli_connect('localhost', 'root', '', 'stock-db');
// if($connect) {
//    print_r("Подключение успешно");
// } else {
//    print_r("Произошла ошибка");
// }
